# Hexamed Asset Management System - Portable Version

## Quick Start

### Windows Users:
1. Double-click `start_windows.bat`
2. Wait for dependencies to install
3. Open browser and go to: http://localhost:5000

### Mac/Linux Users:
1. Open terminal in this folder
2. Run: `./start_unix.sh`
3. Open browser and go to: http://localhost:5000

## Login Credentials
- **Admin**: username=`admin`, password=`hexamed123`
- **Accounts**: username=`accounts`, password=`accounts123`

## System Requirements
- Python 3.7 or later
- Internet connection (for initial setup only)
- Modern web browser (Chrome, Firefox, Safari, Edge)

## Features
✅ Complete asset management system
✅ Multi-level approval workflow
✅ Bill tracking and verification
✅ Inventory management with consumables
✅ User management with role-based access
✅ Activity logging and audit trails
✅ Vendor management
✅ Item assignments and delivery tracking
✅ Excel/CSV export functionality
✅ Bulk upload capabilities

## Data Storage
- Database file (`hexamed.db`) stores all application data
- Uploaded files stored in `uploads/` folder
- All data persists between application restarts
- Portable - copy entire folder to backup/transfer data

## Security Features
- Password hashing with Werkzeug
- Session-based authentication
- Role-based access control
- File upload restrictions
- Activity logging for audit trails

## User Roles & Permissions

### MD (Managing Director)
- Full system access
- Can approve requests at any level
- User management
- System configuration

### Admin
- User management
- Asset management
- Request approvals (level-based)
- System reports

### Accounts/SCM (Supply Chain Management)
- Asset and inventory management
- Vendor management
- Bill upload and tracking
- Request fulfillment
- Item assignments

### Concern Manager
- Department-specific approvals
- View floor-specific requests
- Asset requests

### User/Employee
- Submit asset requests
- Track request status
- View assigned assets

## Troubleshooting

### Application won't start:
1. Ensure Python 3.7+ is installed: `python --version`
2. Install dependencies manually: `pip install flask flask-sqlalchemy werkzeug pandas openpyxl`
3. Run manually: `python main.py`

### Can't access in browser:
1. Check if application started without errors
2. Try: http://127.0.0.1:5000
3. Ensure no firewall blocking port 5000

### Database issues:
1. Delete `hexamed.db` to reset (loses all data)
2. Application will recreate with default users

### File upload issues:
1. Ensure `uploads/` folder exists and is writable
2. Check file size (max 16MB)
3. Verify file type is allowed (PDF, images, documents)

## Support
This is a standalone application. No external services required.
All data stored locally for privacy and security.

## Version Information
Package created: 2025-07-31 12:31:11
Python Flask Application
SQLite Database
Bootstrap 5 UI Framework
