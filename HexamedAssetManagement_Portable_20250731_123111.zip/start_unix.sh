#!/bin/bash
echo "Starting Hexamed Asset Management System..."
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.7 or later"
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt

# Start the application
echo
echo "Starting application..."
echo "Access the application at: http://localhost:5000"
echo
echo "Login credentials:"
echo "  Admin: admin / hexamed123"
echo "  Accounts: accounts / accounts123"
echo
echo "Press Ctrl+C to stop the server"
python3 main.py
