# Hexamed Asset Management System - Render Deployment

## Quick Deploy on Render

1. **Upload this folder to GitHub** (or use Render's direct upload)
2. **Connect to Render**: 
   - Go to https://render.com
   - Click "New +" -> "Web Service"
   - Connect your GitHub repo or upload this folder
3. **Configure Environment Variables** (if not using render.yaml):
   - DATABASE_URL: `postgresql://hexamed_6i8z_user:0VKd5SEHuTIu0lvPSk9WeghNvYf1GJQr@dpg-d2cqoc8gjchc739os36g-a.oregon-postgres.render.com/hexamed_6i8z`
   - SECRET_KEY: `hexamed-render-production-secret-key-change-this-in-production`
   - FLASK_ENV: `production`
4. **Deploy Settings**:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn --bind 0.0.0.0:$PORT --timeout 120 main:app`

## Default Login Credentials

- **Admin**: username: `admin`, password: `hexamed123`
- **Accounts**: username: `accounts`, password: `accounts123`

## Database

This deployment uses your Render PostgreSQL database. The connection is configured in the .env file.

## Security Notes

- Change the SECRET_KEY in production
- Update default passwords after first login
- Configure proper firewall rules
- Enable HTTPS (Render provides this automatically)

## Support

For issues or questions, refer to the application documentation.
